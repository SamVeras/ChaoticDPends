#include <cmath>

#include "structs.hpp"

Vector2F Vector2F::operator+(const Vector2F& other) const {
  return Vector2F{this->x + other.x, this->y + other.y};
};
Vector2F Vector2F::operator-(const Vector2F& other) const {
  return Vector2F{this->x - other.x, this->y - other.y};
};
Vector2F Vector2F::operator*(const float& other) const {
  return Vector2F{this->x * other, this->y * other};
};
Vector2F Vector2F::operator/(const float& other) const {
  if (other == 0.f)
    return *this;
  return Vector2F{this->x / other, this->y / other};
};

Vector2F& Vector2F::operator+=(const Vector2F& other) {
  return *this = *this + other;
};
Vector2F& Vector2F::operator-=(const Vector2F& other) {
  return *this = *this - other;
};
Vector2F& Vector2F::operator*=(const float& other) {
  return *this = *this * other;
};
Vector2F& Vector2F::operator/=(const float& other) {
  return *this = *this / other;
};

bool Vector2F::operator==(const Vector2F& other) const {
  return (this->x == other.x && this->y == other.y);
};
bool Vector2F::operator!=(const Vector2F& other) const {
  return (this->x != other.x || this->y != other.y);
};

float Vector2F::get_magnitude() const {
  return sqrt(powf(x, 2) + powf(y, 2));
};
void Vector2F::set_magnitude(float m) {
  // Primeiro normaliza evitando divisão por 0
  *this = this->get_magnitude() ? *this / this->get_magnitude() : *this;
  *this *= m;
};
void Vector2F::normalize_magnitude() {
  this->set_magnitude(1);
};
Vector2F Vector2F::normalized_vector() const {
  Vector2F r{*this};
  r.normalize_magnitude();
  return r;
};
void Vector2F::limit_magnitude(float m) {
  if (this->get_magnitude() < m)
    return;
  this->set_magnitude(m);
};