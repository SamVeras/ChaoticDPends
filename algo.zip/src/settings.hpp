#pragma once

namespace Settings {
constexpr char* title         = "Flying Snakes";
constexpr int   window_width  = 600;
constexpr int   window_height = 600;
constexpr int   scale         = 2;
constexpr int   framerate     = 30;
constexpr int   logic_width   = window_width / scale;
constexpr int   logic_height  = window_height / scale;
};  // namespace Settings