#include <SDL2/SDL.h>
#include "classes.hpp"
#include "structs.hpp"

int main() {
  Game game;
  auto sn1 = std::make_unique<Snake>(Vector2F{200, 200}, 2, 3, std::make_unique<SeekingBehaviour>(),
                                     std::make_unique<SerpentDrawBehaviour>());
  game.add(std::move(sn1));
  game.run();
}