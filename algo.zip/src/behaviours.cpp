#include "classes.hpp"

void SeekingBehaviour::movement(Movable& a, Vector2F v) {
  Vector2F target{a.position - v};
  target.set_magnitude(a.max_speed);
  target -= a.velocity;
  target.limit_magnitude(a.max_force);
  a.acceleration += target;
}

void SerpentDrawBehaviour::draw(SDL_Renderer* r, Movable m) {
  SDL_SetRenderDrawColor(r, 255, 0, 0, 255);
  SDL_RenderDrawPoint(r, (int)m.position.x, (int)m.position.y);
}