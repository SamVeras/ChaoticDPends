#pragma once
#include <iostream>

struct Vector2F {
  float x = 0.f, y = 0.f;

  Vector2F operator+(const Vector2F&) const;  // Adição de vetores
  Vector2F operator-(const Vector2F&) const;  // Subtraçao de vetores
  Vector2F operator*(const float&) const;     // Multiplicação de vetor por float
  Vector2F operator/(const float&) const;     // Divisão de vetor por float

  // Vector2F& operator=(const const Vector2F&);

  Vector2F& operator+=(const Vector2F&);   // Operador de atribuição com soma de vetores
  Vector2F& operator-=(const Vector2F&);   // Operador de atribuição com subtração de vetores
  Vector2F& operator*=(const float&);      // Operador de atribuição com multiplicação por float
  Vector2F& operator/=(const float&);      // Operador de atribuição com divisão por float

  bool operator==(const Vector2F&) const;  // Verificação de igualdade de vetores
  bool operator!=(const Vector2F&) const;  // Verificação de inequalidade de vetore

  float    get_magnitude() const;          // Retorna a magnitude do vetor
  void     set_magnitude(float);           // Modifica a magnitude do vetor
  void     normalize_magnitude();          // Normaliza a magnitude do vetor (magnitude = 1.0)
  Vector2F normalized_vector() const;  // Retorna uma cópia do vetor normalizado, sem modificá-lo
  void     limit_magnitude(float);     // Limita a magnitude do vetor

  friend std::ostream& operator<<(std::ostream& os, const Vector2F& v);
};
