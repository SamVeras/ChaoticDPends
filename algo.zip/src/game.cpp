#include "classes.hpp"

void Game::add(std::unique_ptr<Movable> m) {
  movables.emplace_back(std::move(m));
}

Game::Game() : running(true) {
  SDL_Init(SDL_INIT_VIDEO);
  win = SDL_CreateWindow(Settings::title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                         Settings::window_width, Settings::window_height, SDL_WINDOW_OPENGL);
  ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
  SDL_RenderSetLogicalSize(ren, Settings::logic_width, Settings::logic_height);
}

Game::~Game() {
  if (ren)
    SDL_DestroyRenderer(ren);
  if (win)
    SDL_DestroyWindow(win);
  SDL_Quit();
}

void Game::update() {
  SDL_Event event;
  while (SDL_PollEvent(&event)) {
    switch (event.type) {
      case SDL_QUIT:
        running = false;
      case SDL_KEYDOWN:
        switch (event.key.keysym.sym) {
          case SDLK_q:
            running = false;
          case SDLK_ESCAPE:
            running = false;
          default:
            break;
        }
      default:
        break;
    }
  }
}

void Game::run() {
  while (running) {
    update();
    SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
    SDL_RenderClear(ren);
    SDL_RenderPresent(ren);
    SDL_Delay(10);
  }
}