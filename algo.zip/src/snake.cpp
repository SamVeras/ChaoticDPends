#include "classes.hpp"
Snake::Snake(Vector2F                           pos,
             float                              max_s,
             float                              max_f,
             std::unique_ptr<MovementBehaviour> m_behave,
             std::unique_ptr<DrawingBehaviour>  d_behave)
    : Movable{pos, {}, {}, max_s, max_f},
      move_behave(std::move(m_behave)),
      draw_behave(std::move(d_behave)){};

void Snake::move() {
  this->move_behave->movement(*this, this->target);
};