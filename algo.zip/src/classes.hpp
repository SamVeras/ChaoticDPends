#pragma once
#include <SDL2/SDL.h>
#include <memory>
#include <vector>

#include "settings.hpp"
#include "structs.hpp"

// Super
class Movable {
 public:
  Vector2F position, velocity, acceleration;
  float    max_speed, max_force;
};

// Abstract

class MovementBehaviour {
 public:
  virtual void movement(Movable& a, Vector2F) = 0;
};

class DrawingBehaviour {
 public:
  virtual void draw(SDL_Renderer*, Movable) = 0;
};

// Behaviours

class SeekingBehaviour : MovementBehaviour {
 public:
  void movement(Movable& a, Vector2F) override;
};

class SerpentDrawBehaviour : DrawingBehaviour {
 public:
  void draw(SDL_Renderer*, Movable) override;
};

// Concrete

class Snake : Movable {
 private:
  std::unique_ptr<MovementBehaviour> move_behave;
  std::unique_ptr<DrawingBehaviour>  draw_behave;
  Vector2F                           target;

 public:
  Snake(Vector2F                           pos,
        float                              max_s,
        float                              max_f,
        std::unique_ptr<MovementBehaviour> m_behave,
        std::unique_ptr<DrawingBehaviour>  d_behave);
  void move();
  void draw();
};

class Game {
 private:
  SDL_Window*          win;
  SDL_Renderer*        ren;
  bool                 running;
  std::vector<Movable> movables;

  void update();

 public:
  void add(std::unique_ptr<Movable> m);

  Game();
  ~Game();

  void run();
};